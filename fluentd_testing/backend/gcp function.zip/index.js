/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

const logger = require('fluent-logger');

logger.configure('fluentd.test'
    , {
    host: '35.229.19.222',
    port: 24224,
    timeout: 3.0,
    reconnectInterval: 600000 // 10 minutes
}
);

exports.helloWorld = (req, res) => {
  logger.emit('GCP function!',{'!':'!'})
  let message = req.query.message || req.body.message || 'Hello World!';
  res.status(200).send(message);
};
//app.post("/insert", function(req, res) {
//    var user_name=req.query.user;
//    var password=req.query.password;
//    logger.emit({'function' : 'insert'});
//    console.log("in insert!");
//    res.send('this is insert! \n your username is:'+user_name+'\n your password is:'+password);
//});